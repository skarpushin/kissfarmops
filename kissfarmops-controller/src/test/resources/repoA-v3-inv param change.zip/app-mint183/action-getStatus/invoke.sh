set -e

FREE_DISK=$(df -h |grep sda2 | tr -s ' ' | cut -d ' ' -f 3)
FREE_MEM=$(free -m |grep Mem | tr -s ' ' | cut -d ' ' -f 4)

echo Free disk: $FREE_DISK
echo Free mem: $FREE_MEM
echo copying temp status to: $RESULT_FILE-temp

cp "result-template.json" "$RESULT_FILE-temp"
sed -i -e "s/PH_freeDisk/$FREE_DISK/g" "$RESULT_FILE-temp"
sed -i -e "s/PH_freeMem/$FREE_MEM/g" "$RESULT_FILE-temp"

mv "$RESULT_FILE-temp" "$RESULT_FILE"

