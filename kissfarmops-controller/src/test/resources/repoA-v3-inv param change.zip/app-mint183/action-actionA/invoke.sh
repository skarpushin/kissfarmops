
echo ActionA triggered $param1
