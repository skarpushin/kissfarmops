set -e

UP=$(service mysql status|grep 'Active: active (running)' | wc -l);
if [ "$UP" -eq 0 ];
then
  MSSQL_ONLINE=false
else
  MSSQL_ONLINE=true
fi

cp "result-template.json" "$RESULT_FILE-temp"
sed -i -e "s/PH_online/$MSSQL_ONLINE/g" "$RESULT_FILE-temp"

mv "$RESULT_FILE-temp" "$RESULT_FILE"

